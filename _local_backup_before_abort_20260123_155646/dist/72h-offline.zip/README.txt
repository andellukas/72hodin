72 hodin – offline krizový poradce (PWA, 100% offline)
====================================================

CO TO JE
- Mini webová aplikace (PWA) pro krizové situace v ČR.
- Vyhledávání bez diakritiky, snese překlepy a synonyma.
- Režimy: PANIKA (okamžité kroky) vs PLNO (detailní postupy).
- Offline: po prvním otevření online se vše nacachuje a funguje bez internetu.

OBSAH
- index.html            hlavní aplikace
- app.js                logika (search/UX)
- faq.json              databáze scénářů
- synonyms.json         synonyma pro search
- sw.js                 service worker cache
- manifest.webmanifest  PWA manifest
- help.html             nápověda
- offline.html          offline self-test
- icons/*               ikony

NASAZENÍ (správce)
- Nahraj obsah složky 72h-offline/ na HTTPS hosting (doporučeno).
- Uživatel otevře index.html přes URL a může nainstalovat PWA.

LOKÁLNÍ TEST
- ve složce 72h-offline spusť:
  python3 -m http.server 8000 --bind 0.0.0.0

PWA INSTALACE
- Android Chrome: menu (⋮) → Nainstalovat / Přidat na plochu
- iPhone Safari: Sdílet → Přidat na plochu
- Desktop Chrome/Edge: ikona instalace v adresním řádku

OFFLINE SELF-TEST
- otevři offline.html → Spustit test
- očekávej CACHE OK + FETCH OK

TÍSŇOVÉ LINKY
- 155 / 112 ohrožení života, 150 požár
